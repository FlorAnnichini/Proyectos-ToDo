# To Do App Basica
![version](https://img.shields.io/badge/Version-2.3.0-orange)
![license](https://img.shields.io/badge/license-Apache-blue)
![dh](https://img.shields.io/badge/Materia-Frontend%20II-red)

En este repositorio se puede encontrar una actividad de la materia de fronend 2, la cual es una aplicación web básica de un **to do** versión web.

Visita previa: [Pulse Aquí](https://paivae.github.io/DH-ToDo/mis-tareas.html "Visitar la web")

Las acciones que se pueden realizar en esta versión son:
* Registro de usuario
* Login de usuario
* Crear una tarea
* Completar una tarea
* Reabrir una tarea
* Borrar una tarea
* Cerrar sesión

También se puede descargar las peticiones de la API para la aplicación insomnia ( rama Insomnia).
